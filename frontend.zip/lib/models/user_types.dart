enum UserType { prefeitura, usuario, admin }
